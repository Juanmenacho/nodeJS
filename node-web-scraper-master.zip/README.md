node-web-scraper
================

Simple web scraper to get a movie name, release year and community rating from IMDB.
To run this example use the following commands:

``` shell
$ npm install
$ node server.js
```

 Then it will start up our node server, navigate to http://localhost:8081/scrape and see what happens.
